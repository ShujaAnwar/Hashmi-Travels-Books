
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import VoucherEntry from './pages/VoucherEntry';
import HotelVoucherEntry from './pages/HotelVoucherEntry';
import HotelVoucherList from './pages/HotelVoucherList';
import PrintHotelVoucher from './pages/PrintHotelVoucher';
import PrintHotelInvoicePKR from './pages/PrintHotelInvoicePKR';
import PrintHotelVoucherSAR from './pages/PrintHotelVoucherSAR';
import PrintHotelInvoiceUSD from './pages/PrintHotelInvoiceUSD';
import ReceiptList from './pages/ReceiptList';
import ReceiptEntry from './pages/ReceiptEntry';
import PrintReceipt from './pages/PrintReceipt';
import TransportVoucherList from './pages/TransportVoucherList';
import TransportVoucherEntry from './pages/TransportVoucherEntry';
import PrintTransportVoucher from './pages/PrintTransportVoucher';
import PrintJournalVoucher from './pages/PrintJournalVoucher';
import PrintCustomerLedger from './pages/PrintCustomerLedger';
import PrintVendorLedger from './pages/PrintVendorLedger';
import PartyLedger from './pages/PartyLedger';
import Reports from './pages/Reports';
import CustomerList from './pages/CustomerList';
import VendorList from './pages/VendorList';
import AccountList from './pages/AccountList';
import Security from './pages/Security';
import { db } from './store';
import { Search, Printer, Copy } from 'lucide-react';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState('dashboard');
  const [selectedVoucherId, setSelectedVoucherId] = useState<string | null>(null);
  const [selectedReceiptId, setSelectedReceiptId] = useState<string | null>(null);
  const [selectedTransportId, setSelectedTransportId] = useState<string | null>(null);
  const [selectedLedgerId, setSelectedLedgerId] = useState<string | null>(null);
  const [printVariant, setPrintVariant] = useState<'PKR' | 'SAR' | 'USD' | 'BOOKING'>('BOOKING');
  const [searchTerm, setSearchTerm] = useState('');

  // UI Preferences
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('ui-theme') as any) || 'light');
  const [isCompact, setIsCompact] = useState<boolean>(() => localStorage.getItem('ui-compact') === 'true');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('ui-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('ui-compact', isCompact.toString());
  }, [isCompact]);
  
  // Clone States
  const [clonedHotelData, setClonedHotelData] = useState<any>(null);
  const [clonedTransportData, setClonedTransportData] = useState<any>(null);
  const [clonedReceiptData, setClonedReceiptData] = useState<any>(null);
  const [clonedJVData, setClonedJVData] = useState<any>(null);

  // Edit States
  const [editingHotelData, setEditingHotelData] = useState<any>(null);
  const [editingTransportData, setEditingTransportData] = useState<any>(null);
  const [editingReceiptData, setEditingReceiptData] = useState<any>(null);
  const [editingJVData, setEditingJVData] = useState<any>(null);

  const handleViewHotelVoucher = (id: string, variant: 'PKR' | 'SAR' | 'USD' | 'BOOKING') => {
    setSelectedVoucherId(id);
    setPrintVariant(variant);
    setActivePage('hotel-voucher-view');
  };

  const handleCloneHotel = (id: string) => {
    const original = db.getHotelVouchers().find(v => v.id === id);
    if (original) {
      setClonedHotelData(original);
      setEditingHotelData(null);
      setActivePage('hotel-voucher-new');
    }
  };

  const handleEditHotel = (id: string) => {
    const original = db.getHotelVouchers().find(v => v.id === id);
    if (original) {
      setEditingHotelData(original);
      setClonedHotelData(null);
      setActivePage('hotel-voucher-new');
    }
  };

  const handleCloneTransport = (id: string) => {
    const original = db.getTransportVouchers().find(v => v.id === id);
    if (original) {
      setClonedTransportData(original);
      setEditingTransportData(null);
      setActivePage('transport-voucher-new');
    }
  };

  const handleEditTransport = (id: string) => {
    const original = db.getTransportVouchers().find(v => v.id === id);
    if (original) {
      setEditingTransportData(original);
      setClonedTransportData(null);
      setActivePage('transport-voucher-new');
    }
  };

  const handleCloneReceipt = (id: string) => {
    const original = db.getReceipts().find(v => v.id === id);
    if (original) {
      setClonedReceiptData(original);
      setEditingReceiptData(null);
      setActivePage('receipt-new');
    }
  };

  const handleEditReceipt = (id: string) => {
    const original = db.getReceipts().find(v => v.id === id);
    if (original) {
      setEditingReceiptData(original);
      setClonedReceiptData(null);
      setActivePage('receipt-new');
    }
  };

  const handleCloneJV = (id: string) => {
    const original = db.getVouchers().find(v => v.id === id);
    if (original) {
      setClonedJVData(original);
      setEditingJVData(null);
      setActivePage('voucher-new');
    }
  };

  const handleEditJV = (id: string) => {
    const original = db.getVouchers().find(v => v.id === id);
    if (original) {
      setEditingJVData(original);
      setClonedJVData(null);
      setActivePage('voucher-new');
    }
  };

  const handlePrintReceipt = (id: string) => {
    setSelectedReceiptId(id);
    setActivePage('receipt-view');
  };

  const handlePrintTransport = (id: string) => {
    setSelectedTransportId(id);
    setActivePage('transport-view');
  };

  const handlePrintJV = (id: string) => {
    setSelectedVoucherId(id);
    setActivePage('jv-view');
  };

  const handlePrintCustomerLedger = (id: string) => {
    setSelectedLedgerId(id);
    setActivePage('customer-ledger-print');
  };

  const handlePrintVendorLedger = (id: string) => {
    setSelectedLedgerId(id);
    setActivePage('vendor-ledger-print');
  };

  const handleViewCustomerLedger = (id: string) => {
    setSelectedLedgerId(id);
    setActivePage('customer-ledger-view');
  };

  const handleViewVendorLedger = (id: string) => {
    setSelectedLedgerId(id);
    setActivePage('vendor-ledger-view');
  };

  const renderContent = () => {
    if (activePage === 'hotel-voucher-view' && selectedVoucherId) {
      if (printVariant === 'PKR') return <PrintHotelInvoicePKR id={selectedVoucherId} onBack={() => setActivePage('hotel-vouchers')} />;
      if (printVariant === 'SAR') return <PrintHotelVoucherSAR id={selectedVoucherId} onBack={() => setActivePage('hotel-vouchers')} />;
      if (printVariant === 'USD') return <PrintHotelInvoiceUSD id={selectedVoucherId} onBack={() => setActivePage('hotel-vouchers')} />;
      return <PrintHotelVoucher id={selectedVoucherId} onBack={() => setActivePage('hotel-vouchers')} />;
    }

    if (activePage === 'receipt-view' && selectedReceiptId) {
      return <PrintReceipt id={selectedReceiptId} onBack={() => setActivePage('receipts')} />;
    }

    if (activePage === 'transport-view' && selectedTransportId) {
      return <PrintTransportVoucher id={selectedTransportId} onBack={() => setActivePage('transport-vouchers')} />;
    }

    if (activePage === 'jv-view' && selectedVoucherId) {
      return <PrintJournalVoucher id={selectedVoucherId} onBack={() => setActivePage('vouchers')} />;
    }

    if (activePage === 'customer-ledger-print' && selectedLedgerId) {
      return <PrintCustomerLedger id={selectedLedgerId} onBack={() => setActivePage('customer-ledger-view')} />;
    }

    if (activePage === 'vendor-ledger-print' && selectedLedgerId) {
      return <PrintVendorLedger id={selectedLedgerId} onBack={() => setActivePage('vendor-ledger-view')} />;
    }

    if (activePage === 'customer-ledger-view' && selectedLedgerId) {
      return <PartyLedger isCompact={isCompact} partyId={selectedLedgerId} partyType="Customer" onBack={() => setActivePage('customers')} onPrint={() => handlePrintCustomerLedger(selectedLedgerId)} />;
    }

    if (activePage === 'vendor-ledger-view' && selectedLedgerId) {
      return <PartyLedger isCompact={isCompact} partyId={selectedLedgerId} partyType="Vendor" onBack={() => setActivePage('vendors')} onPrint={() => handlePrintVendorLedger(selectedLedgerId)} />;
    }

    switch (activePage) {
      case 'dashboard':
        return <Dashboard isCompact={isCompact} />;
      case 'vouchers':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <div className="relative w-full max-w-sm sm:max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Search vouchers..." 
                  className={`w-full pl-10 pr-4 border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl focus:ring-emerald-500 ${isCompact ? 'py-1.5 text-xs' : 'py-2.5 text-sm'}`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'}`}>No.</th>
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'}`}>Date</th>
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'}`}>Type</th>
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'}`}>Description</th>
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'} text-right`}>Amount (PKR)</th>
                      <th className={`px-6 ${isCompact ? 'py-3' : 'py-5'} text-right`}>Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {db.getVouchers()
                      .filter(v => v.voucher_no.toLowerCase().includes(searchTerm.toLowerCase()) || v.description.toLowerCase().includes(searchTerm.toLowerCase()))
                      .reverse()
                      .map(v => (
                      <tr key={v.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors group">
                        <td className={`px-6 ${isCompact ? 'py-2 text-xs' : 'py-4 text-sm'} font-black text-blue-600`}>{v.voucher_no}</td>
                        <td className={`px-6 ${isCompact ? 'py-2 text-xs' : 'py-4 text-sm'} text-slate-500 font-bold`}>{v.date}</td>
                        <td className={`px-6 ${isCompact ? 'py-2' : 'py-4'}`}>
                          <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider ${
                            v.type === 'Hotel' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400' :
                            v.type === 'Sales' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 
                            v.type === 'Receipt' ? 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400' : 
                            v.type === 'Transport' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                            v.type === 'Cash' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                          }`}>
                            {v.type}
                          </span>
                        </td>
                        <td className={`px-6 ${isCompact ? 'py-2 text-xs' : 'py-4 text-sm'} text-slate-600 dark:text-slate-400 font-medium truncate max-w-[200px]`}>{v.description}</td>
                        <td className={`px-6 ${isCompact ? 'py-2 text-xs' : 'py-4 text-sm'} text-right font-black text-slate-900 dark:text-slate-100`}>Rs. {v.total_amount.toLocaleString()}</td>
                        <td className={`px-6 ${isCompact ? 'py-2' : 'py-4'} text-right`}>
                          <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button onClick={() => handleEditJV(v.id)} className="p-1.5 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 rounded-lg text-slate-400 hover:text-emerald-600 transition-all" title="Edit JV">
                               <Copy size={14} />
                             </button>
                             <button onClick={() => handleCloneJV(v.id)} className="p-1.5 hover:bg-blue-100 dark:hover:bg-blue-900/30 rounded-lg text-slate-400 hover:text-blue-600 transition-all" title="Clone JV">
                               <Copy size={14} />
                             </button>
                             <button onClick={() => handlePrintJV(v.id)} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all" title="Print JV">
                               <Printer size={14} />
                             </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      case 'hotel-vouchers':
        return <HotelVoucherList 
          isCompact={isCompact}
          onNew={() => { setClonedHotelData(null); setEditingHotelData(null); setActivePage('hotel-voucher-new'); }} 
          onView={handleViewHotelVoucher} 
          onClone={handleCloneHotel}
          onEdit={handleEditHotel}
        />;
      case 'hotel-voucher-new':
        return <HotelVoucherEntry 
          isCompact={isCompact}
          initialData={clonedHotelData} 
          editingData={editingHotelData}
          onComplete={() => { setClonedHotelData(null); setEditingHotelData(null); setActivePage('hotel-vouchers'); }} 
        />;
      case 'transport-vouchers':
        return <TransportVoucherList 
          isCompact={isCompact}
          onNew={() => { setClonedTransportData(null); setEditingTransportData(null); setActivePage('transport-voucher-new'); }} 
          onPrint={handlePrintTransport} 
          onClone={handleCloneTransport}
          onEdit={handleEditTransport}
        />;
      case 'transport-voucher-new':
        return <TransportVoucherEntry 
          isCompact={isCompact}
          initialData={clonedTransportData} 
          editingData={editingTransportData}
          onBack={() => setActivePage('transport-vouchers')} 
          onComplete={() => { setClonedTransportData(null); setEditingTransportData(null); setActivePage('transport-vouchers'); }} 
        />;
      case 'receipts':
        return <ReceiptList 
          isCompact={isCompact}
          onNew={() => { setClonedReceiptData(null); setEditingReceiptData(null); setActivePage('receipt-new'); }} 
          onPrint={handlePrintReceipt} 
          onClone={handleCloneReceipt}
          onEdit={handleEditReceipt}
        />;
      case 'receipt-new':
        return <ReceiptEntry 
          isCompact={isCompact}
          initialData={clonedReceiptData} 
          editingData={editingReceiptData}
          onBack={() => setActivePage('receipts')} 
          onComplete={() => { setClonedReceiptData(null); setEditingReceiptData(null); setActivePage('receipts'); }} 
        />;
      case 'voucher-new':
        return <VoucherEntry 
          isCompact={isCompact}
          initialData={clonedJVData} 
          editingData={editingJVData}
          onComplete={() => { setClonedJVData(null); setEditingJVData(null); setActivePage('vouchers'); }} 
        />;
      case 'customers':
        return <CustomerList isCompact={isCompact} onViewLedger={handleViewCustomerLedger} onPrintLedger={handlePrintCustomerLedger} />;
      case 'vendors':
        return <VendorList isCompact={isCompact} onViewLedger={handleViewVendorLedger} onPrintLedger={handlePrintVendorLedger} />;
      case 'accounts':
        return <AccountList isCompact={isCompact} />;
      case 'reports':
        return <Reports isCompact={isCompact} />;
      case 'security':
        return <Security isCompact={isCompact} />;
      default:
        return <Dashboard isCompact={isCompact} />;
    }
  };

  return (
    <Layout 
      activePage={activePage} 
      setActivePage={setActivePage}
      theme={theme}
      setTheme={setTheme}
      isCompact={isCompact}
      setIsCompact={setIsCompact}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
